/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package co.edu.unipiloto.ws.testws.entidad;

import co.edu.unipiloto.testws.testws_2020.model.Person;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Random;
import javax.ws.rs.Consumes;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;


/**
 *
 * @author Home
 */
@Path("service")
public class Service {
    int sumaSalario = 0;
    
    private static Map<Integer, modelo> persons = new HashMap<Integer, modelo>();
    
    static {
        for (int i = 0; i < 10; i++) {
            modelo person = new modelo();
            int id = i + 1;
            person.setId(id);
            person.setFullName("My wonderfull Person" + id);
            person.setAge(new Random().nextInt(40) + 1);
            persons.put(id, person);
        }
    }
    
    
    
    public modelo getPersonByIdXML(int id) {
       return persons.get(id);
    }
    
     public modelo getPersonBySalarioXML(int Salario) {
       return persons.get(Salario);
    }
    
    public modelo getPersonByIdJson(int id) {
       return persons.get(id);
    }
    
   
    public List<modelo> getAllPersonsInXML() {
        return new ArrayList<modelo>(persons.values());
    }
    
    public List<modelo> getAllPersonsInJson() {
        return new ArrayList<modelo>(persons.values());
    }
        
    public List<modelo> getAllSalariosInJson() {
        return new ArrayList<modelo>(persons.values());
    }
        
    public modelo addPersonInJson (modelo person) {
        System.out.println(person.getId());
        persons.put(new Integer (person.getId()), person);
        return person;
    }  
    
    @GET
    @Path("/getAllPersonsInJson")
    @Produces(MediaType.APPLICATION_XML)
    public List<modelo> getAllPersonsInJson()){
        return new ArrayList<modelo>(persons.values());
    }  
    
    @POST
    @Path("/addPersonInJson")
    @Produces(MediaType.APPLICATION_JSON)
    @Consumes(MediaType.APPLICATION_JSON)
    public modelo addPersonInJson (modelo person) {
        System.out.println(person.getId());
        persons.put(new Integer(person.getId()), person);
        return person;
    }
    
    @GET
    @Path("/getPersonByIdXML/{id}")
    @Produces(MediaType.APPLICATION_XML)
    public modelo getPersonByIdXML(@PathParam("id") int id){
        return persons.get(id);
    }
    

    @GET
    @Path("/getPersonByIdJson/{id}")
    @Produces(MediaType.APPLICATION_XML)
    public modelo getPersonByIdJson(@PathParam("id") int id){
        return persons.get(id);
    }   
    
    @GET
    @Path("/getAllPersonsInXML/{id}")
    @Produces(MediaType.APPLICATION_XML)
    public List<modelo> getAllPersonsInXML()){
        return new ArrayList<modelo>(persons.values());
    }   

    @GET
    @Path("/getPersonBySalarioXML/{Salario}")
    @Produces(MediaType.APPLICATION_XML)
    public modelo getPersonBySalarioXML(@PathParam("Salario") int Salario){
        return persons.get(Salario);
    }
    
        @GET
    @Path("/getPersonBySalarioJson/{id}")
    @Produces(MediaType.APPLICATION_XML)
    public modelo getPersonBySalarioXML(@PathParam("Salario") int Salario){
        for (int i = 0; i < Salario.length; i++) {
            sumaSalario += Salario[i];
            return persons.get(Salario);
        }
        
    }
}
